/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prati_sgcq.audit;

import java.io.Serializable;
import java.net.UnknownHostException;
import java.util.Date;
import javax.swing.JOptionPane;
import org.hibernate.envers.EntityTrackingRevisionListener;
import org.hibernate.envers.RevisionListener;
import org.hibernate.envers.RevisionType;
import prati_sgcq.view.config.FrmMotivoAuditoria;

/**
 *
 * @author rafael.lopes
 */
public class AuditListener implements RevisionListener, EntityTrackingRevisionListener {

    @Override
    public void newRevision(Object revisionEntity) {
        try {
            String computador;
            String user = System.getProperty("user") == null ? "not found" : System.getProperty("user");
            String userComputador = System.getProperty("user.name");
            try {
                computador = java.net.InetAddress.getLocalHost().getHostName();
            } catch (UnknownHostException ex1) {
                computador = "not found";
            }
            Audit audit = new Audit();
            try {
                new FrmMotivoAuditoria(null, true, audit).setVisible(true);
            } catch (Exception ex) {
                audit.setMotivo("");
            }
            AuditRevision auditRevision = (AuditRevision) revisionEntity;
            auditRevision.setUltimaModificacaoPor(user);
            auditRevision.setUltimaModificacao(new Date());
            auditRevision.setComputador(computador);
            auditRevision.setUserComputador(userComputador);
            auditRevision.setMotivo(audit.getMotivo());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao gerar newRevision: " + ex);
        }
    }

    @Override
    public void entityChanged(Class entityClass, String entityName,
            Serializable entityId, RevisionType revisionType,
            Object revisionEntity) {
        try {
            String entityClassName = entityClass.getName();
            Integer modifiedType = revisionType.ordinal();
            Integer idEntity = Integer.parseInt(entityId.toString());
            ((AuditRevision) revisionEntity).addModifiedEntityType(entityClassName, modifiedType, idEntity);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao gerar entityChanged: " + ex);
        }
    }

}
