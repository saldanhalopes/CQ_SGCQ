/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prati_sgcq.audit;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import org.hibernate.envers.DefaultRevisionEntity;
import org.hibernate.envers.RevisionEntity;

/**
 *
 * @author rafael.lopes
 */
@Entity
@Table(name = "tba_audit_revinfo")
@RevisionEntity(AuditListener.class)
public class AuditRevision extends DefaultRevisionEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private int id;

    @Column(name = "ultima_modificacao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date ultimaModificacao;

    @Column(name = "modificado_por")
    private String ultimaModificacaoPor;
    
    @Column(name = "computador")
    private String computador;

    @Column(name = "user_computador")
    private String userComputador;
    
    @Column(name = "motivo")
    private String motivo;

    @OneToMany(mappedBy = "revision", cascade = {CascadeType.PERSIST, CascadeType.REMOVE})
    private Set<AuditEntityType> auditEntityType = new HashSet<>();

    
    public AuditRevision() {
    }

    public Date getUltimaModificacao() {
        return ultimaModificacao;
    }

    public void setUltimaModificacao(Date ultimaModificacao) {
        this.ultimaModificacao = ultimaModificacao;
    }

    public String getUltimaModificacaoPor() {
        return ultimaModificacaoPor;
    }

    public void setUltimaModificacaoPor(String ultimaModificacaoPor) {
        this.ultimaModificacaoPor = ultimaModificacaoPor;
    }

    public String getComputador() {
        return computador;
    }

    public void setComputador(String computador) {
        this.computador = computador;
    }

    public String getUserComputador() {
        return userComputador;
    }

    public void setUserComputador(String userComputador) {
        this.userComputador = userComputador;
    }

    public Set<AuditEntityType> getModifiedEntityTypes() {
        return auditEntityType;
    }

    public void setModifiedEntityTypes(Set<AuditEntityType> auditEntityType) {
        this.auditEntityType = auditEntityType;
    }
    
    public void addModifiedEntityType(String entityClassName, Integer modifiedType, Integer idEntity) {
        auditEntityType.add(new AuditEntityType(this, entityClassName, modifiedType, idEntity));
    }

    public Set<AuditEntityType> getAuditEntityType() {
        return auditEntityType;
    }

    public void setAuditEntityType(Set<AuditEntityType> auditEntityType) {
        this.auditEntityType = auditEntityType;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

}
