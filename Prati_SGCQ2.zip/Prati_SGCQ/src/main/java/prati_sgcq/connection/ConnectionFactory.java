/*
 * Copyright (C) 2018 rafael
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package prati_sgcq.connection;

import com.itextpdf.text.Chapter;
import com.itextpdf.text.pdf.StringUtils;
import com.lowagie.text.Section;
import java.awt.print.Book;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.SharedCacheMode;
import javax.persistence.ValidationMode;
import javax.persistence.spi.ClassTransformer;
import javax.persistence.spi.PersistenceUnitInfo;
import javax.sql.DataSource;
import static jdk.nashorn.internal.runtime.ECMAException.CREATE;
import static org.hibernate.cfg.AvailableSettings.DIALECT;
import static org.hibernate.cfg.AvailableSettings.GENERATE_STATISTICS;
import static org.hibernate.cfg.AvailableSettings.HBM2DDL_AUTO;
import static org.hibernate.cfg.AvailableSettings.JPA_JDBC_DRIVER;
import static org.hibernate.cfg.AvailableSettings.JPA_JDBC_URL;
import static org.hibernate.cfg.AvailableSettings.QUERY_STARTUP_CHECKING;
import static org.hibernate.cfg.AvailableSettings.SHOW_SQL;
import static org.hibernate.cfg.AvailableSettings.STATEMENT_BATCH_SIZE;
import static org.hibernate.cfg.AvailableSettings.USE_QUERY_CACHE;
import static org.hibernate.cfg.AvailableSettings.USE_REFLECTION_OPTIMIZER;
import static org.hibernate.cfg.AvailableSettings.USE_SECOND_LEVEL_CACHE;
import static org.hibernate.cfg.AvailableSettings.USE_STRUCTURED_CACHE;
import org.hibernate.dialect.Oracle12cDialect;
import static org.hibernate.jpa.AvailableSettings.JDBC_DRIVER;
import static org.hibernate.jpa.AvailableSettings.JDBC_URL;
import org.hibernate.jpa.HibernatePersistenceProvider;
import org.hibernate.jpamodelgen.xml.jaxb.PersistenceUnitTransactionType;

/**
 *
 * @author rafael
 */
public class ConnectionFactory {

    private static final ThreadLocal<EntityManager> threadLocal = new ThreadLocal<>();

    private static EntityManagerFactory factory;

    public ConnectionFactory() {

    }

    /**
     * Cria uma entity manager factory Ãºnica e o retorna em todas as demais
     * chamadas
     *
     * @return
     */
    public static EntityManagerFactory getFactory() {
        if (factory == null || !factory.isOpen()) {
            //factory = Persistence.createEntityManagerFactory("prati_sgcq_PU");
            factory = Persistence.createEntityManagerFactory(new HibernatePersistenceProvider().createContainerEntityManagerFactory(
            archiverPersistenceUnitInfo(),
            ImmutableMap.<String, Object>builder()
                    .put(JPA_JDBC_DRIVER, JDBC_DRIVER)
                    .put(JPA_JDBC_URL, JDBC_URL)
                    .put(DIALECT, Oracle12cDialect.class)
                    .put(HBM2DDL_AUTO, CREATE)
                    .put(SHOW_SQL, false)
                    .put(QUERY_STARTUP_CHECKING, false)
                    .put(GENERATE_STATISTICS, false)
                    .put(USE_REFLECTION_OPTIMIZER, false)
                    .put(USE_SECOND_LEVEL_CACHE, false)
                    .put(USE_QUERY_CACHE, false)
                    .put(USE_STRUCTURED_CACHE, false)
                    .put(STATEMENT_BATCH_SIZE, 20)
                    .build()););
        }
        return factory;
    }

    /**
     * Cria um entity manager unico (se criar = true) para a thread e o retorna
     * em todas as demais chamadas
     *
     * @param criar
     * @return
     */
    public static EntityManager em(boolean criar) {
        EntityManager em = (EntityManager) threadLocal.get();
        if (em == null || !em.isOpen()) {
            if (criar) {
                em = getFactory().createEntityManager();
                threadLocal.set(em);
            }
        } else {
            if (!criar) {
                em.close();
                factory.close();
            }
        }
        return em;
    }

    /**
     * Cria um entity manager Ãºnico para a thread e o retorna em todas as
     * demais chamadas
     *
     * @return
     */
    public static EntityManager em() {
        return em(true);
    }

    public static Connection getConnection() {
        String DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
        String URL = "jdbc:sqlserver://PRTMC1939:1433;databaseName=db_prati_sgcq";
        try {
            Class.forName(DRIVER);
            return DriverManager.getConnection(URL, "db_sys", "Beast666");
        } catch (ClassNotFoundException | SQLException ex) {
            throw new RuntimeException("Erro na Conexão: " + ex);
        }
    }

    public static void closeConection(Connection conn) {
        try {
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException ex) {
            throw new RuntimeException("Erro para fechar Conexão: " + ex);
        }
    }

    public static void closeConection(Connection conn, PreparedStatement stmt) {
        closeConection(conn);
        try {
            if (stmt != null) {
                stmt.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(ConnectionFactory.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void closeConection(Connection conn, PreparedStatement stmt, ResultSet rs) {
        closeConection(conn, stmt);
        try {
            if (rs != null) {
                rs.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(ConnectionFactory.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    	private EntityManager createEntityManager(String dbUrl, String dbUser, String dbPassword) {
 
		Properties props = new Properties();
		props.put("hibernate.connection.url", dbUrl);
		props.put("hibernate.connection.username", dbUser);
 
		if (StringUtils.hasText(dbPassword)) {
			props.put("hibernate.connection.password", dbPassword);
		}
 
		PersistenceUnitInfo persistenceUnitInfo = new PersistenceUnitInfo() {
 
			@Override
			public Properties getProperties() {
				return props;
			}
 
			@Override
			public List<String> getManagedClassNames() {
				return Arrays.asList(Author.class.getName(), Book.class.getName(), Chapter.class.getName(),
						Genre.class.getName(), Section.class.getName());
			}
 
			@Override
			public String getPersistenceUnitName() {
				return "TestUnit";
			}
 
			@Override
			public String getPersistenceProviderClassName() {
				return HibernatePersistenceProvider.class.getName();
			}
 
			@Override
			public PersistenceUnitTransactionType getTransactionType() {
				return null;
			}
 
			@Override
			public DataSource getJtaDataSource() {
				return null;
			}
 
			@Override
			public DataSource getNonJtaDataSource() {
				return null;
			}
 
			@Override
			public List<String> getMappingFileNames() {
				return null;
			}
 
			@Override
			public List<URL> getJarFileUrls() {
				return null;
			}
 
			@Override
			public URL getPersistenceUnitRootUrl() {
				return null;
			}
 
			@Override
			public boolean excludeUnlistedClasses() {
				return false;
			}
 
			@Override
			public SharedCacheMode getSharedCacheMode() {
				return null;
			}
 
			@Override
			public ValidationMode getValidationMode() {
				return null;
			}
 
			@Override
			public String getPersistenceXMLSchemaVersion() {
				return null;
			}
 
			@Override
			public ClassLoader getClassLoader() {
				return null;
			}
 
			@Override
			public void addTransformer(ClassTransformer transformer) {
 
			}
 
			@Override
			public ClassLoader getNewTempClassLoader() {
				return null;
			}
		};
 
		HibernatePersistenceProvider hibernatePersistenceProvider = new HibernatePersistenceProvider();
 
		EntityManagerFactory entityManagerFactory = hibernatePersistenceProvider
				.createContainerEntityManagerFactory(persistenceUnitInfo, Collections.EMPTY_MAP);
 
		return entityManagerFactory.createEntityManager();
 
	}
    
    
}
