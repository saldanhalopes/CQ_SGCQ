/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prati_sgcq.util;

import javax.swing.JOptionPane;
import prati_sgcq.view.dashboard;
import prati_sgcq.view.progress;

/**
 *
 * @author rafael
 */
public class AbreSistema {

    public static void main(String[] args) {
        
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(progress.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                progress progress = new progress();
                progress.setVisible(true);
                new Thread() {
                    @Override
                    public void run() {
                        dashboard dashboard = new dashboard(progress);
                        dashboard.setVisible(true);
                    }
                }.start();
            }
        });

    }
}
