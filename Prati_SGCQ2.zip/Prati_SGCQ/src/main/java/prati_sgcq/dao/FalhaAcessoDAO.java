package prati_sgcq.dao;

import prati_sgcq.model.FalhaAcesso;

/**
 *
 * @author rafael
 */
public class FalhaAcessoDAO extends GenenicoDAO<FalhaAcesso> {

}
