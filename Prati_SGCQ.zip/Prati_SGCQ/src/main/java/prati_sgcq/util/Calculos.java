/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prati_sgcq.util;

import java.awt.Component;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import javax.swing.JFormattedTextField;
import javax.swing.JPanel;
import org.apache.commons.math3.stat.StatUtils;

/**
 *
 * @author rafael.lopes
 */
public class Calculos {

    public Calculos() {
    }

    public static String Arred(Double value, Integer qtdeCasasDecimais) {
        try {
            BigDecimal resultado = new BigDecimal(value).setScale(qtdeCasasDecimais, RoundingMode.HALF_UP);
            return value <= 0.0 ? null : resultado.toString();
        } catch (Exception e) {
            return null;
        }

    }

    public static Double Soma(JPanel pnl) {
        ArrayList<Double> values = new ArrayList();
        for (Component c : pnl.getComponents()) {
            if (c instanceof JFormattedTextField) {
                JFormattedTextField f = (JFormattedTextField) c;
                if (f.getValue() != null) {
                    values.add((Double) f.getValue());
                }
            }
        }
        try {
            Double resultado = StatUtils.sum(values.stream().mapToDouble(Double::doubleValue).toArray());
            return resultado.isNaN() ? 0.0 : resultado;
        } catch (Exception e) {
            return null;
        }

    }

    public static Double Media(JPanel pnl) {
        ArrayList<Double> values = new ArrayList();
        for (Component c : pnl.getComponents()) {
            if (c instanceof JFormattedTextField) {
                JFormattedTextField f = (JFormattedTextField) c;
                if (f.getValue() != null) {
                    values.add((Double) f.getValue());
                }
            }
        }
        try {
            Double resultado = StatUtils.mean(values.stream().mapToDouble(Double::doubleValue).toArray());
            return resultado.isNaN() ? 0.0 : resultado;
        } catch (Exception e) {
            return null;
        }
    }

    public static Double Min(JPanel pnl) {
        ArrayList<Double> values = new ArrayList();
        for (Component c : pnl.getComponents()) {
            if (c instanceof JFormattedTextField) {
                JFormattedTextField f = (JFormattedTextField) c;
                if (f.getValue() != null) {
                    values.add((Double) f.getValue());
                }
            }
        }
        try {
            Double resultado = StatUtils.min(values.stream().mapToDouble(Double::doubleValue).toArray());
            return resultado.isNaN() ? 0.0 : resultado;
        } catch (Exception e) {
            return null;
        }
    }

    public static Double Max(JPanel pnl) {
        ArrayList<Double> values = new ArrayList();
        for (Component c : pnl.getComponents()) {
            if (c instanceof JFormattedTextField) {
                JFormattedTextField f = (JFormattedTextField) c;
                if (f.getValue() != null) {
                    values.add((Double) f.getValue());
                }
            }
        }
        try {
            Double resultado = StatUtils.max(values.stream().mapToDouble(Double::doubleValue).toArray());
            return resultado.isNaN() ? 0.0 : resultado;
        } catch (Exception e) {
            return null;
        }
    }

    public static Double Porcentagem(JPanel pnl, Double value) {
        try {
            Double resultado = value * 100 / Media(pnl);
            return resultado.isNaN() ? 0.0 : resultado;
        } catch (Exception e) {
            return null;
        }
    }

    public static Double MinPorcentagem(JPanel pnl) {
        try {
            Double resultado = Min(pnl) * 100 / Media(pnl);
            return resultado.isNaN() ? 0.0 : resultado;
        } catch (Exception e) {
            return null;
        }
    }

    public static Double MaxPorcentagem(JPanel pnl) {
        try {
            Double resultado = Max(pnl) * 100 / Media(pnl);
            return resultado.isNaN() ? 0.0 : resultado;
        } catch (Exception e) {
            return null;
        }
    }

//    public static BigDecimal Media(JPanel pnl, Integer qtdeCasasDecimais) {
//        BigDecimal sum = BigDecimal.ZERO;
//        Double Number = 0.0;
//        for (Component c : pnl.getComponents()) {
//            if (c instanceof JFormattedTextField) {
//                JFormattedTextField f = (JFormattedTextField) c;
//                if (f.getValue() != null) {
//                    sum = sum.add(BigDecimal.valueOf((Double) f.getValue()));
//                    Number++;
//                }
//            }
//        }
//        return (Number == 0 ? null : sum.divide(BigDecimal.valueOf(Number), qtdeCasasDecimais, RoundingMode.HALF_UP));
//    }
}
