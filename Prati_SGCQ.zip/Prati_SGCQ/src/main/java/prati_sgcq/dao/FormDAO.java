package prati_sgcq.dao;

import prati_sgcq.model.Form;

/**
 *
 * @author rafael
 */
public class FormDAO extends GenenicoDAO<Form> {
    
}
